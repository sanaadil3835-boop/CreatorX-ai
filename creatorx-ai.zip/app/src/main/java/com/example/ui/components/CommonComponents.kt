package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CreationItem
import com.example.data.model.UserProfile
import com.example.ui.theme.AmberCreditTertiary
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.NeonVioletPrimary
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.ObsidianDarkSurface
import com.example.ui.theme.ObsidianDarkSurfaceVariant
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextWhiteHighContrast
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioTopBar(
    title: String,
    profile: UserProfile?,
    canNavigateBack: Boolean = false,
    onNavigateBack: () -> Unit = {},
    onCreditClick: () -> Unit = {},
    onProfileClick: () -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhiteHighContrast
                )
                if (profile?.isPremium == true) {
                    Text(
                        text = profile.subscriptionTier.uppercase(),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CyberCyanSecondary,
                        letterSpacing = 1.sp
                    )
                }
            }
        },
        navigationIcon = {
            if (canNavigateBack) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("nav_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextWhiteHighContrast
                    )
                }
            }
        },
        actions = {
            // Credits Pill Badge
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onCreditClick() }
                    .border(1.dp, AmberCreditTertiary.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                    .testTag("credit_balance_badge"),
                color = Color(0xFF1E1B13)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Credits",
                        tint = AmberCreditTertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${profile?.credits ?: 0}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberCreditTertiary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // User Avatar
            IconButton(
                onClick = onProfileClick,
                modifier = Modifier.testTag("profile_avatar_button")
            ) {
                if (!profile?.photoUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = profile?.photoUrl,
                        contentDescription = "Profile",
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .border(1.dp, NeonVioletPrimary, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(NeonVioletPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (profile?.displayName?.firstOrNull() ?: 'C').uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = ObsidianDarkBackground
        )
    )
}

@Composable
fun NeonCard(
    modifier: Modifier = Modifier,
    borderColor: Color = Color(0xFF222B3D),
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .then(
                if (onClick != null) Modifier.clickable { onClick() } else Modifier
            )
            .border(1.dp, borderColor, RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = ObsidianDarkSurface
        )
    ) {
        content()
    }
}

@Composable
fun CreditCostBadge(cost: Long) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF241D12),
        border = androidx.compose.foundation.BorderStroke(1.dp, AmberCreditTertiary.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = null,
                tint = AmberCreditTertiary,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$cost Credits",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = AmberCreditTertiary
            )
        }
    }
}

@Composable
fun CreationCard(
    item: CreationItem,
    onShare: () -> Unit = {}
) {
    val clipboardManager = LocalClipboardManager.current
    NeonCard(
        modifier = Modifier.testTag("creation_item_${item.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = NeonVioletPrimary.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonVioletPrimary.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = item.type.replace("_", " ").uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonVioletPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                Row {
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(item.prompt))
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Prompt",
                            tint = TextMutedSlate,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(
                        onClick = onShare,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = TextMutedSlate,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = item.title.ifBlank { "Untitled Creation" },
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = item.prompt,
                fontSize = 13.sp,
                color = TextMutedSlate,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            if (item.mediaUrl.isNotBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF161C28))
                ) {
                    AsyncImage(
                        model = item.mediaUrl,
                        contentDescription = item.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
    }
}

// Interactive Before/After photo comparison slider
@Composable
fun BeforeAfterComparisonSlider(
    beforeUrl: String,
    afterUrl: String,
    modifier: Modifier = Modifier
) {
    var sliderFraction by remember { mutableFloatStateOf(0.5f) }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, Color(0xFF2A344A), RoundedCornerShape(18.dp))
    ) {
        val widthPx = constraints.maxWidth.toFloat()

        // 1. "After" full background
        AsyncImage(
            model = afterUrl,
            contentDescription = "After Enhancement",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // 2. "Before" masked with clip
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .width(with(LocalDensity.current) { (widthPx * sliderFraction).toDp() })
                .clip(RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp))
        ) {
            AsyncImage(
                model = beforeUrl,
                contentDescription = "Before Enhancement",
                modifier = Modifier
                    .fillMaxHeight()
                    .width(with(LocalDensity.current) { widthPx.toDp() }),
                contentScale = ContentScale.Crop
            )
        }

        // 3. Draggable Divider Line & Knob
        Box(
            modifier = Modifier
                .offset { IntOffset((widthPx * sliderFraction).roundToInt() - 2.dp.roundToPx(), 0) }
                .fillMaxHeight()
                .width(4.dp)
                .background(Color.White)
        )

        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        (widthPx * sliderFraction).roundToInt() - 16.dp.roundToPx(),
                        (constraints.maxHeight / 2) - 16.dp.roundToPx()
                    )
                }
                .size(32.dp)
                .clip(CircleShape)
                .background(NeonVioletPrimary)
                .border(2.dp, Color.White, CircleShape)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures { _, dragAmount ->
                        val newFraction = (sliderFraction + (dragAmount / widthPx)).coerceIn(0.05f, 0.95f)
                        sliderFraction = newFraction
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "◀▶",
                fontSize = 10.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        // Labels
        Surface(
            color = Color.Black.copy(alpha = 0.6f),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(12.dp)
        ) {
            Text(
                text = "BEFORE (Original)",
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        Surface(
            color = Color.Black.copy(alpha = 0.6f),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(12.dp)
        ) {
            Text(
                text = "AFTER (4K AI)",
                color = CyberCyanSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}
