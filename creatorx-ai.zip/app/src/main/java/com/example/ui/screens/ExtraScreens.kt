package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CreationItem
import com.example.data.model.CreditTransaction
import com.example.data.model.PromptTemplate
import com.example.data.model.StudioTool
import com.example.ui.components.CreationCard
import com.example.ui.components.CreditCostBadge
import com.example.ui.components.NeonCard
import com.example.ui.theme.AmberCreditTertiary
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.NeonVioletPrimary
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextWhiteHighContrast
import com.example.ui.viewmodel.StudioUiState
import com.example.ui.viewmodel.StudioViewModel

// ==========================================
// 8. Prompt Library Screen
// ==========================================
@Composable
fun PromptLibraryScreen(
    viewModel: StudioViewModel,
    onUsePrompt: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val promptsFromDb by viewModel.prompts.collectAsState()
    val allPrompts = if (promptsFromDb.isNotEmpty()) promptsFromDb else samplePrompts
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Photography", "Shorts Hooks", "Voice Scripts", "Cyberpunk", "3D Render")

    val filteredPrompts = allPrompts.filter {
        (selectedCategory == "All" || it.category.equals(selectedCategory, ignoreCase = true)) &&
                (searchQuery.isBlank() || it.title.contains(searchQuery, ignoreCase = true) || it.prompt.contains(searchQuery, ignoreCase = true))
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("prompt_library_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ToolHeader(
                title = "Creator Prompt Vault",
                subtitle = "Discover high-converting prompts for image, video, and shorts",
                creditCost = 0L
            )
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("prompt_search_field"),
                shape = RoundedCornerShape(14.dp),
                placeholder = { Text("Search prompts, formulas, styles...", color = TextMutedSlate) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = TextMutedSlate)
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF111622),
                    unfocusedContainerColor = Color(0xFF0E131C),
                    focusedBorderColor = NeonVioletPrimary,
                    unfocusedBorderColor = Color(0xFF222B3D),
                    focusedTextColor = TextWhiteHighContrast,
                    unfocusedTextColor = TextWhiteHighContrast
                )
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categories) { cat ->
                    StudioChip(
                        text = cat,
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat }
                    )
                }
            }
        }

        items(filteredPrompts) { promptItem ->
            PromptLibraryDetailCard(
                prompt = promptItem,
                onUse = { onUsePrompt(promptItem.prompt) }
            )
        }
    }
}

@Composable
fun PromptLibraryDetailCard(
    prompt: PromptTemplate,
    onUse: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    NeonCard(
        modifier = Modifier.testTag("prompt_detail_${prompt.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CyberCyanSecondary.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyanSecondary.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = prompt.category.uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyanSecondary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
                Text("♥ ${prompt.likesCount} Saves", fontSize = 11.sp, color = TextMutedSlate)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = prompt.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = prompt.prompt,
                fontSize = 13.sp,
                color = TextMutedSlate
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { clipboardManager.setText(AnnotatedString(prompt.prompt)) }
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy Prompt",
                        tint = TextMutedSlate,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Button(
                    onClick = onUse,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonVioletPrimary,
                        contentColor = Color.White
                    ),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("Use in Studio", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==========================================
// 9. User Accounts & Profiles Screen
// ==========================================
@Composable
fun ProfileScreen(
    viewModel: StudioViewModel,
    onSignOut: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val profile by viewModel.userProfile.collectAsState()
    val creations by viewModel.creations.collectAsState()
    var selectedFilter by remember { mutableStateOf("All") }
    val filters = listOf("All", "image", "text_to_video", "voice", "short")

    val filteredCreations = creations.filter {
        selectedFilter == "All" || it.type == selectedFilter
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("profile_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            NeonCard {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(NeonVioletPrimary)
                            .border(2.dp, CyberCyanSecondary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (!profile?.photoUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = profile?.photoUrl,
                                contentDescription = "Profile Avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            Text(
                                text = (profile?.displayName?.firstOrNull() ?: 'C').uppercase(),
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = profile?.displayName ?: "CreatorX Artist",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhiteHighContrast
                    )

                    Text(
                        text = profile?.email ?: "",
                        fontSize = 12.sp,
                        color = TextMutedSlate
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF1B2332),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A364C))
                        ) {
                            Text(
                                text = "TIER: ${profile?.subscriptionTier ?: "Free"}",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (profile?.isPremium == true) CyberCyanSecondary else TextMutedSlate,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF241D12),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AmberCreditTertiary.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "BALANCE: ${profile?.credits ?: 0} CREDITS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AmberCreditTertiary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onSignOut,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF202636),
                            contentColor = TextWhiteHighContrast
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .testTag("sign_out_button")
                    ) {
                        Text("Sign Out", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        item {
            Text(
                text = "My Studio Portfolio (${creations.size})",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { f ->
                    StudioChip(
                        text = if (f == "All") "All Creations" else f.replace("_", " ").uppercase(),
                        selected = selectedFilter == f,
                        onClick = { selectedFilter = f }
                    )
                }
            }
        }

        if (filteredCreations.isEmpty()) {
            item {
                NeonCard {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("No creations yet in this category", color = TextMutedSlate, fontSize = 13.sp)
                        Text("Use any of the 12 AI studio engines to generate art!", color = CyberCyanSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(filteredCreations) { item ->
                CreationCard(item = item)
            }
        }
    }
}

// ==========================================
// 10. Daily Free Credits & Referral Rewards
// ==========================================
@Composable
fun CreditsAndReferralScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val profile by viewModel.userProfile.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val uiState by viewModel.uiState.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    var inputCode by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("credits_rewards_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Credits & Referral Rewards",
                subtitle = "Earn daily bonus credits and invite fellow creators",
                creditCost = 0L
            )
        }

        // Feedback Banner
        if (uiState is StudioUiState.Success) {
            item {
                Surface(
                    color = Color(0xFF0F2E22),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981))
                ) {
                    Text(
                        text = (uiState as StudioUiState.Success).message,
                        color = Color(0xFF10B981),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        } else if (uiState is StudioUiState.Error) {
            item {
                Surface(
                    color = Color(0xFF2E1313),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.error)
                ) {
                    Text(
                        text = (uiState as StudioUiState.Error).message,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(14.dp)
                    )
                }
            }
        }

        // Daily Claim Card
        item {
            NeonCard(borderColor = AmberCreditTertiary.copy(alpha = 0.5f)) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "DAILY STREAK CLAIM",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = AmberCreditTertiary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Streak: ${profile?.streakDays ?: 1} Days",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextWhiteHighContrast
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Every day you log in, claim +50 free credits directly into your wallet.",
                        fontSize = 13.sp,
                        color = TextMutedSlate
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.claimDailyCredits() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("claim_button_wallet"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AmberCreditTertiary,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Claim +50 Credits", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }

        // Referral Card
        item {
            NeonCard(borderColor = CyberCyanSecondary.copy(alpha = 0.5f)) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "INVITE CREATORS (+100 CREDITS)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = CyberCyanSecondary,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Share your unique invite code. When a friend joins, both of you receive +100 bonus credits!",
                        fontSize = 13.sp,
                        color = TextMutedSlate
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF121927))
                            .border(1.dp, Color(0xFF222F46), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = profile?.referralCode ?: "CREATOR88",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextWhiteHighContrast,
                            letterSpacing = 2.sp
                        )

                        Row {
                            IconButton(
                                onClick = {
                                    clipboardManager.setText(AnnotatedString(profile?.referralCode ?: ""))
                                }
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberCyanSecondary)
                            }
                            IconButton(
                                onClick = {
                                    val shareIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, "Join me on CreatorX AI! Use my creator referral code: ${profile?.referralCode} for 100 free credits!")
                                        type = "text/plain"
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share Referral Code"))
                                }
                            ) {
                                Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = CyberCyanSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Have a friend's code?", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = inputCode,
                            onValueChange = { inputCode = it },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("referral_input_field"),
                            shape = RoundedCornerShape(12.dp),
                            placeholder = { Text("Enter code", fontSize = 12.sp, color = TextMutedSlate) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhiteHighContrast,
                                unfocusedTextColor = TextWhiteHighContrast,
                                focusedBorderColor = CyberCyanSecondary,
                                unfocusedBorderColor = Color(0xFF25334A)
                            )
                        )
                        Button(
                            onClick = { viewModel.applyReferral(inputCode) },
                            modifier = Modifier.height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyanSecondary,
                                contentColor = Color.Black
                            )
                        ) {
                            Text("Redeem", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Transaction Ledger
        item {
            Text(
                text = "Credit Transactions Ledger",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )
        }

        if (transactions.isEmpty()) {
            item {
                Text("No transactions logged yet.", fontSize = 13.sp, color = TextMutedSlate)
            }
        } else {
            items(transactions) { tx ->
                TransactionRow(tx = tx)
            }
        }
    }
}

@Composable
fun TransactionRow(tx: CreditTransaction) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF101520),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1D2638))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tx.description,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = TextWhiteHighContrast
                )
                Text(
                    text = tx.type.replace("_", " ").uppercase(),
                    fontSize = 10.sp,
                    color = TextMutedSlate
                )
            }
            Text(
                text = if (tx.amount > 0) "+${tx.amount}" else "${tx.amount}",
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (tx.amount > 0) Color(0xFF10B981) else Color(0xFFEF4444)
            )
        }
    }
}

// ==========================================
// 11. Premium Subscriptions Screen
// ==========================================
@Composable
fun SubscriptionScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val profile by viewModel.userProfile.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("subscription_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Creator Pro Passes",
                subtitle = "Upgrade your studio for unlimited high-priority renders",
                creditCost = 0L
            )
        }

        item {
            SubscriptionTierCard(
                tierName = "Creator Pro",
                price = "$14.99 / month",
                creditsGrant = "+750 Credits Monthly",
                isCurrent = profile?.subscriptionTier == "Creator Pro",
                features = listOf(
                    "Fast-track Gemini 3.8 model priority queue",
                    "4K Ultra-HD photo upscaling & face detailer",
                    "Unlimited prompt library bookmarks",
                    "Watermark removal on all exported shorts"
                ),
                highlightColor = NeonVioletPrimary,
                onUpgrade = { viewModel.upgradeTier("Creator Pro") }
            )
        }

        item {
            SubscriptionTierCard(
                tierName = "Studio Max",
                price = "$29.99 / month",
                creditsGrant = "+2,000 Credits Monthly",
                isCurrent = profile?.subscriptionTier == "Studio Max",
                features = listOf(
                    "Everything in Creator Pro",
                    "60-second full video storyboard generator",
                    "Neural voice cloning & custom voice profiles",
                    "Commercial broadcast rights license",
                    "Priority 24/7 Creator Concierge"
                ),
                highlightColor = CyberCyanSecondary,
                onUpgrade = { viewModel.upgradeTier("Studio Max") }
            )
        }
    }
}

@Composable
fun SubscriptionTierCard(
    tierName: String,
    price: String,
    creditsGrant: String,
    isCurrent: Boolean,
    features: List<String>,
    highlightColor: Color,
    onUpgrade: () -> Unit
) {
    NeonCard(borderColor = if (isCurrent) highlightColor else Color(0xFF222B3D)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tierName,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = highlightColor
                )
                if (isCurrent) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = highlightColor.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, highlightColor)
                    ) {
                        Text(
                            text = "ACTIVE PLAN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = highlightColor,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = price,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )

            Text(
                text = creditsGrant,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = AmberCreditTertiary
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = Color(0xFF222B3D))
            Spacer(modifier = Modifier.height(16.dp))

            features.forEach { feat ->
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = highlightColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(text = feat, fontSize = 13.sp, color = TextWhiteHighContrast)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onUpgrade,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("upgrade_${tierName.lowercase().replace(" ", "_")}"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isCurrent) Color(0xFF1E2638) else highlightColor,
                    contentColor = if (isCurrent) TextMutedSlate else Color.Black
                ),
                enabled = !isCurrent
            ) {
                Text(
                    text = if (isCurrent) "Current Active Plan" else "Upgrade to $tierName",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// ==========================================
// 12. Admin Dashboard Screen
// ==========================================
@Composable
fun AdminDashboardScreen(
    viewModel: StudioViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val profile by viewModel.userProfile.collectAsState()
    var targetUid by remember { mutableStateOf("") }
    var grantAmount by remember { mutableStateOf("500") }

    val isAdmin = profile?.role == "admin" || profile?.email?.equals("hamdh3835@gmail.com", ignoreCase = true) == true

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("admin_dashboard_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Admin Telemetry & Console",
                subtitle = "Manage infrastructure health, model latency, and credit grants",
                creditCost = 0L
            )
        }

        if (!isAdmin) {
            item {
                NeonCard(borderColor = MaterialTheme.colorScheme.error) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Access Restricted", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
                        Text("Only authenticated administrators have write access to system controls.", fontSize = 12.sp, color = TextMutedSlate, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            // System telemetry status cards
            item {
                NeonCard(borderColor = CyberCyanSecondary.copy(alpha = 0.5f)) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text("SYSTEM TELEMETRY & ENGINE STATUS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberCyanSecondary)
                        Spacer(modifier = Modifier.height(12.dp))

                        TelemetryRow(label = "Gemini 3.8 Flash Engine", value = "Operational (App Check Verified)", statusColor = Color(0xFF10B981))
                        TelemetryRow(label = "Cloud Firestore Named DB", value = "Connected (Port 8085/Online)", statusColor = Color(0xFF10B981))
                        TelemetryRow(label = "Google Sign-In Credential Manager", value = "Active (SHA-1 Registered)", statusColor = Color(0xFF10B981))
                        TelemetryRow(label = "App Attestation", value = "Enforced (ReCAPTCHA + Debug)", statusColor = Color(0xFF10B981))
                    }
                }
            }

            // User Credit Grant Tool
            item {
                NeonCard {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text("MANUAL CREDIT GRANT (ADMIN ONLY)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = AmberCreditTertiary)
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Grant creative credits directly to any user account UID for support or bonuses.", fontSize = 12.sp, color = TextMutedSlate)

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = targetUid,
                            onValueChange = { targetUid = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_target_uid_field"),
                            shape = RoundedCornerShape(12.dp),
                            placeholder = { Text("Target User UID", fontSize = 12.sp, color = TextMutedSlate) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhiteHighContrast,
                                unfocusedTextColor = TextWhiteHighContrast,
                                focusedBorderColor = AmberCreditTertiary,
                                unfocusedBorderColor = Color(0xFF222B3D)
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = grantAmount,
                            onValueChange = { grantAmount = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_grant_amount_field"),
                            shape = RoundedCornerShape(12.dp),
                            placeholder = { Text("Credit Amount (e.g. 500)", fontSize = 12.sp, color = TextMutedSlate) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextWhiteHighContrast,
                                unfocusedTextColor = TextWhiteHighContrast,
                                focusedBorderColor = AmberCreditTertiary,
                                unfocusedBorderColor = Color(0xFF222B3D)
                            )
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val amount = grantAmount.toLongOrNull() ?: 500L
                                if (targetUid.isNotBlank()) {
                                    viewModel.adminGrantCredits(targetUid, amount)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("admin_grant_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberCreditTertiary,
                                contentColor = Color.Black
                            )
                        ) {
                            Text("Grant Credits to User", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TelemetryRow(label: String, value: String, statusColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 12.sp, color = TextWhiteHighContrast)
        Text(text = value, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold)
    }
}
