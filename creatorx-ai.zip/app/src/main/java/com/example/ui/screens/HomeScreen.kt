package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MotionPhotosOn
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CreationItem
import com.example.data.model.PromptTemplate
import com.example.data.model.StudioTool
import com.example.data.model.UserProfile
import com.example.ui.components.CreationCard
import com.example.ui.components.CreditCostBadge
import com.example.ui.components.NeonCard
import com.example.ui.theme.AmberCreditTertiary
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.NeonVioletPrimary
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextWhiteHighContrast
import com.example.ui.viewmodel.StudioViewModel

@Composable
fun HomeScreen(
    viewModel: StudioViewModel,
    onToolSelected: (StudioTool) -> Unit,
    onPromptSelected: (String) -> Unit
) {
    val profile by viewModel.userProfile.collectAsState()
    val creations by viewModel.creations.collectAsState()
    val prompts by viewModel.prompts.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(horizontal = 16.dp)
            .testTag("home_screen"),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Daily Free Credits Streak Banner
        item {
            DailyStreakBanner(
                profile = profile,
                onClaim = { viewModel.claimDailyCredits() }
            )
        }

        // 2. Studio Engines Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AI Studio Engines",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhiteHighContrast
                )
                Text(
                    text = "12 Tools",
                    fontSize = 12.sp,
                    color = CyberCyanSecondary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // 3. Studio Tools Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val tools = StudioTool.entries.toTypedArray()
                for (i in tools.indices step 2) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        StudioToolCard(
                            tool = tools[i],
                            modifier = Modifier.weight(1f),
                            onClick = { onToolSelected(tools[i]) }
                        )
                        if (i + 1 < tools.size) {
                            StudioToolCard(
                                tool = tools[i + 1],
                                modifier = Modifier.weight(1f),
                                onClick = { onToolSelected(tools[i + 1]) }
                            )
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // 4. Trending Community Prompts
        item {
            Text(
                text = "Trending Prompt Vault",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(end = 16.dp)
            ) {
                val featuredPrompts = if (prompts.isNotEmpty()) prompts else samplePrompts
                items(featuredPrompts) { p ->
                    PromptVaultCard(prompt = p, onSelect = { onPromptSelected(p.prompt) })
                }
            }
        }

        // 5. Recent Creator Portfolio
        if (creations.isNotEmpty()) {
            item {
                Text(
                    text = "Recent Studio Creations",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhiteHighContrast
                )
            }
            items(creations.take(3)) { creation ->
                CreationCard(item = creation)
            }
        }
    }
}

@Composable
fun DailyStreakBanner(
    profile: UserProfile?,
    onClaim: () -> Unit
) {
    NeonCard(
        borderColor = AmberCreditTertiary.copy(alpha = 0.5f),
        modifier = Modifier.testTag("daily_streak_banner")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color(0xFF261D0F),
                            Color(0xFF141A28)
                        )
                    )
                )
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AmberCreditTertiary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Streak",
                                tint = AmberCreditTertiary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DAY ${profile?.streakDays ?: 1} STREAK",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = AmberCreditTertiary,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Daily Free Credits",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhiteHighContrast
                            )
                        }
                    }

                    CreditCostBadge(cost = 50L)
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Claim +50 free credits every 24 hours to generate images, videos, and AI voices.",
                    fontSize = 13.sp,
                    color = TextMutedSlate
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onClaim,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("claim_daily_credits_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberCreditTertiary,
                        contentColor = Color.Black
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Claim +50 Daily Credits",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun StudioToolCard(
    tool: StudioTool,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val icon = when (tool) {
        StudioTool.IMAGE_GEN -> Icons.Default.Image
        StudioTool.TEXT_TO_VIDEO -> Icons.Default.Videocam
        StudioTool.IMAGE_TO_VIDEO -> Icons.Default.MotionPhotosOn
        StudioTool.PHOTO_ENHANCER -> Icons.Default.AutoFixHigh
        StudioTool.VOICE_GEN -> Icons.Default.RecordVoiceOver
        StudioTool.SHORTS_CREATOR -> Icons.Default.SmartDisplay
        StudioTool.VIDEO_EDITOR -> Icons.Default.Movie
        StudioTool.PROMPT_LIBRARY -> Icons.AutoMirrored.Filled.MenuBook
        StudioTool.USER_PROFILE -> Icons.Default.AccountCircle
        StudioTool.DAILY_CREDITS -> Icons.Default.MonetizationOn
        StudioTool.PREMIUM_PLANS -> Icons.Default.Star
        StudioTool.ADMIN_DASHBOARD -> Icons.Default.AdminPanelSettings
    }

    NeonCard(
        modifier = modifier
            .testTag("tool_card_${tool.id}"),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(NeonVioletPrimary, CyberCyanSecondary)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = tool.title,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (tool.creditCost > 0) {
                    Text(
                        text = "${tool.creditCost}C",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = AmberCreditTertiary
                    )
                } else {
                    Text(
                        text = "FREE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyanSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = tool.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = tool.subtitle,
                fontSize = 11.sp,
                color = TextMutedSlate,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PromptVaultCard(
    prompt: PromptTemplate,
    onSelect: () -> Unit
) {
    Surface(
        modifier = Modifier
            .width(240.dp)
            .clickable { onSelect() }
            .testTag("prompt_card_${prompt.id}"),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF131824),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF232D42))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = prompt.category.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanSecondary
                )
                Text(
                    text = "♥ ${prompt.likesCount}",
                    fontSize = 11.sp,
                    color = TextMutedSlate
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = prompt.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = prompt.prompt,
                fontSize = 12.sp,
                color = TextMutedSlate,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Tap to load into Studio ➔",
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = NeonVioletPrimary
            )
        }
    }
}

val samplePrompts = listOf(
    PromptTemplate(
        id = "sample_1",
        title = "Cyberpunk Neo-Tokyo",
        category = "Photography",
        toolTarget = "image",
        prompt = "Futuristic skyscraper city in 2099, neon purple holograms, volumetric rainy reflections, 8K ultra-detailed cinematic",
        likesCount = 340
    ),
    PromptTemplate(
        id = "sample_2",
        title = "Viral AI Short Hook",
        category = "Shorts Hooks",
        toolTarget = "short",
        prompt = "The secret psychology trick that 99% of people miss, but will completely change your day in 30 seconds",
        likesCount = 520
    ),
    PromptTemplate(
        id = "sample_3",
        title = "Trailer Narration",
        category = "Voice Scripts",
        toolTarget = "voice",
        prompt = "In a world where algorithms control dreams, one creator dared to imagine beyond the code.",
        likesCount = 210
    )
)
