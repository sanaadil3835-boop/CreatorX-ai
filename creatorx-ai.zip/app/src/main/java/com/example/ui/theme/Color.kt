package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon Studio Core Palette
val NeonVioletPrimary = Color(0xFF8B5CF6)
val NeonVioletLight = Color(0xFFA78BFA)
val NeonVioletDark = Color(0xFF6D28D9)

val CyberCyanSecondary = Color(0xFF06B6D4)
val CyberCyanLight = Color(0xFF22D3EE)
val CyberCyanDark = Color(0xFF0891B2)

val AmberCreditTertiary = Color(0xFFF59E0B)
val AmberCreditLight = Color(0xFFFBBF24)

// Dark Theme Surfaces (Deep Obsidian Studio)
val ObsidianDarkBackground = Color(0xFF080B11)
val ObsidianDarkSurface = Color(0xFF10141E)
val ObsidianDarkSurfaceVariant = Color(0xFF181F2E)
val ObsidianDarkSurfaceElevated = Color(0xFF222B3D)
val ObsidianBorderGlow = Color(0x268B5CF6) // subtle 15% violet glow

// Text & Content
val TextWhiteHighContrast = Color(0xFFF8FAFC)
val TextMutedSlate = Color(0xFF94A3B8)
val TextSubtleDark = Color(0xFF64748B)

// Status & Indicators
val EmeraldSuccess = Color(0xFF10B981)
val CoralError = Color(0xFFEF4444)

// Light Studio Palette
val StudioLightBackground = Color(0xFFF8FAFC)
val StudioLightSurface = Color(0xFFFFFFFF)
val StudioLightSurfaceVariant = Color(0xFFF1F5F9)
val StudioLightTextPrimary = Color(0xFF0F172A)
val StudioLightTextSecondary = Color(0xFF475569)
