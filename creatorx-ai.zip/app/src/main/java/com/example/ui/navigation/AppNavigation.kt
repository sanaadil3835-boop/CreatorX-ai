package com.example.ui.navigation

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import com.example.data.model.StudioTool
import com.example.ui.auth.signOutUser
import com.example.ui.components.StudioTopBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CreditsAndReferralScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImageGeneratorScreen
import com.example.ui.screens.ImageToVideoScreen
import com.example.ui.screens.PhotoEnhancerScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.PromptLibraryScreen
import com.example.ui.screens.ShortsCreatorScreen
import com.example.ui.screens.SubscriptionScreen
import com.example.ui.screens.TextToVideoScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.screens.VoiceGeneratorScreen
import com.example.ui.theme.AmberCreditTertiary
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.NeonVioletPrimary
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextWhiteHighContrast
import com.example.ui.viewmodel.GenerationViewModel
import com.example.ui.viewmodel.StudioViewModel

enum class MainNavDestination(
    val route: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    HOME("home", "Studio", Icons.Default.AutoAwesome),
    PROMPTS("prompts", "Vault", Icons.AutoMirrored.Filled.MenuBook),
    WALLET("credits", "Credits", Icons.Default.Bolt),
    PROFILE("profile", "Creator", Icons.Default.AccountCircle)
}

@Composable
fun AppNavigation(
    studioViewModel: StudioViewModel,
    genViewModel: GenerationViewModel,
    onSignOutComplete: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }
    val profile by studioViewModel.userProfile.collectAsState()

    var currentScreen by remember { mutableStateOf("home") }
    var activePrompt by remember { mutableStateOf("") }

    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 600

    val topBarTitle = when (currentScreen) {
        "home" -> "CreatorX Studio"
        "prompts" -> "Prompt Vault"
        "credits" -> "Credit Ledger"
        "profile" -> "Creator Profile"
        "image" -> "AI Image Generator"
        "text_to_video" -> "Text-to-Video"
        "image_to_video" -> "Image-to-Video"
        "photo_enhancer" -> "AI Photo Enhancer"
        "voice" -> "AI Voice Studio"
        "short" -> "Shorts Creator"
        "video_editor" -> "Video Editor"
        "subscriptions" -> "Studio Passes"
        "admin" -> "Admin Dashboard"
        else -> "CreatorX AI"
    }

    val isSubScreen = currentScreen !in listOf("home", "prompts", "credits", "profile")

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground),
        topBar = {
            StudioTopBar(
                title = topBarTitle,
                profile = profile,
                canNavigateBack = isSubScreen,
                onNavigateBack = { currentScreen = "home" },
                onCreditClick = { currentScreen = "credits" },
                onProfileClick = { currentScreen = "profile" }
            )
        },
        bottomBar = {
            if (!isTablet && !isSubScreen) {
                StudioBottomNav(
                    currentScreen = currentScreen,
                    onNavigate = { currentScreen = it }
                )
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isTablet && !isSubScreen) {
                StudioNavRail(
                    currentScreen = currentScreen,
                    onNavigate = { currentScreen = it }
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            ) {
                when (currentScreen) {
                    "home" -> HomeScreen(
                        viewModel = studioViewModel,
                        onToolSelected = { tool ->
                            currentScreen = tool.id
                        },
                        onPromptSelected = { selectedPrompt ->
                            activePrompt = selectedPrompt
                            currentScreen = "image"
                        }
                    )
                    "prompts" -> PromptLibraryScreen(
                        viewModel = studioViewModel,
                        onUsePrompt = { p ->
                            activePrompt = p
                            currentScreen = "image"
                        },
                        onBack = { currentScreen = "home" }
                    )
                    "credits" -> CreditsAndReferralScreen(
                        viewModel = studioViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "profile" -> ProfileScreen(
                        viewModel = studioViewModel,
                        onSignOut = {
                            signOutUser(
                                credentialManager = credentialManager,
                                scope = coroutineScope,
                                onSignOutComplete = onSignOutComplete
                            )
                        },
                        onBack = { currentScreen = "home" }
                    )

                    // Specialized AI Engines
                    "image" -> ImageGeneratorScreen(
                        viewModel = genViewModel,
                        initialPrompt = activePrompt,
                        onBack = { currentScreen = "home" }
                    )
                    "text_to_video" -> TextToVideoScreen(
                        viewModel = genViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "image_to_video" -> ImageToVideoScreen(
                        viewModel = genViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "photo_enhancer" -> PhotoEnhancerScreen(
                        viewModel = genViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "voice" -> VoiceGeneratorScreen(
                        viewModel = genViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "short" -> ShortsCreatorScreen(
                        viewModel = genViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "video_editor" -> VideoEditorScreen(
                        viewModel = genViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "subscriptions" -> SubscriptionScreen(
                        viewModel = studioViewModel,
                        onBack = { currentScreen = "home" }
                    )
                    "admin" -> AdminDashboardScreen(
                        viewModel = studioViewModel,
                        onBack = { currentScreen = "home" }
                    )
                }
            }
        }
    }
}

@Composable
fun StudioBottomNav(
    currentScreen: String,
    onNavigate: (String) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .border(
                1.dp,
                Color(0xFF1F293D),
                RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            )
            .testTag("studio_bottom_nav"),
        containerColor = Color(0xFF0D111A)
    ) {
        MainNavDestination.entries.forEach { dest ->
            val isSelected = currentScreen == dest.route
            NavigationBarItem(
                selected = isSelected,
                onClick = { onNavigate(dest.route) },
                icon = {
                    Icon(
                        imageVector = dest.icon,
                        contentDescription = dest.title,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = dest.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = CyberCyanSecondary,
                    indicatorColor = NeonVioletPrimary,
                    unselectedIconColor = TextMutedSlate,
                    unselectedTextColor = TextMutedSlate
                )
            )
        }
    }
}

@Composable
fun StudioNavRail(
    currentScreen: String,
    onNavigate: (String) -> Unit
) {
    NavigationRail(
        containerColor = Color(0xFF0D111A),
        modifier = Modifier.testTag("studio_nav_rail")
    ) {
        MainNavDestination.entries.forEach { dest ->
            val isSelected = currentScreen == dest.route
            NavigationRailItem(
                selected = isSelected,
                onClick = { onNavigate(dest.route) },
                icon = {
                    Icon(imageVector = dest.icon, contentDescription = dest.title)
                },
                label = {
                    Text(dest.title, fontSize = 11.sp)
                },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = Color.White,
                    indicatorColor = NeonVioletPrimary,
                    unselectedIconColor = TextMutedSlate,
                    unselectedTextColor = TextMutedSlate
                )
            )
        }
    }
}
