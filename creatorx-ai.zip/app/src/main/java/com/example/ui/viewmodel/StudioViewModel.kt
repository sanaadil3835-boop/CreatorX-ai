package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CreationItem
import com.example.data.model.CreditTransaction
import com.example.data.model.PromptTemplate
import com.example.data.model.UserProfile
import com.example.data.repository.FirestoreUserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface StudioUiState {
    data object Loading : StudioUiState
    data class Success(val message: String) : StudioUiState
    data class Error(val message: String) : StudioUiState
    data object Idle : StudioUiState
}

class StudioViewModel(
    private val userRepository: FirestoreUserRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<StudioUiState>(StudioUiState.Idle)
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    val userProfile: StateFlow<UserProfile?> = userRepository.observeUserProfile()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = null
        )

    val creations: StateFlow<List<CreationItem>> = userRepository.observeUserCreations()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val transactions: StateFlow<List<CreditTransaction>> = userRepository.observeUserTransactions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val prompts: StateFlow<List<PromptTemplate>> = userRepository.observePromptLibrary()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    init {
        // Initialize user record if first launch
        viewModelScope.launch {
            userRepository.getOrCreateUserProfile()
        }
    }

    fun claimDailyCredits() {
        viewModelScope.launch {
            _uiState.value = StudioUiState.Loading
            userRepository.claimDailyCredits()
                .onSuccess { bonus ->
                    _uiState.value = StudioUiState.Success("Claimed +$bonus free credits!")
                }
                .onFailure { err ->
                    _uiState.value = StudioUiState.Error(err.message ?: "Failed to claim daily credits.")
                }
        }
    }

    fun applyReferral(code: String) {
        viewModelScope.launch {
            _uiState.value = StudioUiState.Loading
            userRepository.applyReferralCode(code)
                .onSuccess { bonus ->
                    _uiState.value = StudioUiState.Success("Referral applied! +$bonus credits granted.")
                }
                .onFailure { err ->
                    _uiState.value = StudioUiState.Error(err.message ?: "Invalid referral code.")
                }
        }
    }

    fun upgradeTier(tier: String) {
        viewModelScope.launch {
            _uiState.value = StudioUiState.Loading
            userRepository.upgradeSubscription(tier)
                .onSuccess {
                    _uiState.value = StudioUiState.Success("Welcome to $tier! Pro features unlocked.")
                }
                .onFailure { err ->
                    _uiState.value = StudioUiState.Error(err.message ?: "Subscription upgrade failed.")
                }
        }
    }

    fun adminGrantCredits(targetUid: String, amount: Long) {
        viewModelScope.launch {
            _uiState.value = StudioUiState.Loading
            userRepository.adminGrantCredits(targetUid, amount)
                .onSuccess {
                    _uiState.value = StudioUiState.Success("Granted +$amount credits to $targetUid")
                }
                .onFailure { err ->
                    _uiState.value = StudioUiState.Error(err.message ?: "Admin action failed")
                }
        }
    }

    fun clearFeedback() {
        _uiState.value = StudioUiState.Idle
    }
}
