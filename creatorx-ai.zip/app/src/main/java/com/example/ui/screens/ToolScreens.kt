package com.example.ui.screens

import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.components.BeforeAfterComparisonSlider
import com.example.ui.components.CreditCostBadge
import com.example.ui.components.NeonCard
import com.example.ui.theme.AmberCreditTertiary
import com.example.ui.theme.CyberCyanSecondary
import com.example.ui.theme.NeonVioletPrimary
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextWhiteHighContrast
import com.example.ui.viewmodel.GenState
import com.example.ui.viewmodel.GenerationViewModel

// ==========================================
// 1. AI Image Generator Screen
// ==========================================
@Composable
fun ImageGeneratorScreen(
    viewModel: GenerationViewModel,
    initialPrompt: String = "",
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var prompt by remember { mutableStateOf(initialPrompt.ifBlank { "Futuristic cyberpunk samurai standing in rainy neon city" }) }
    var selectedStyle by remember { mutableStateOf("Cinematic") }
    var selectedRatio by remember { mutableStateOf("1:1") }
    val state by viewModel.imageGenState.collectAsState()

    val styles = listOf("Cinematic", "Photorealistic", "Cyberpunk", "Anime", "3D Render", "Digital Art")
    val ratios = listOf("1:1", "9:16", "16:9")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("image_gen_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "AI Image Generator",
                subtitle = "Generate ultra-realistic visual art with Google Gemini",
                creditCost = 15L,
                engineTag = "Gemini Nano Banana 2.1 & 3.8",
                outputType = "Real Media Output & AI Enhancement"
            )
        }

        item {
            PromptInputBox(
                value = prompt,
                onValueChange = { prompt = it },
                label = "Describe your image in detail..."
            )
        }

        item {
            Text("Style Preset", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(styles) { style ->
                    StudioChip(
                        text = style,
                        selected = selectedStyle == style,
                        onClick = { selectedStyle = style }
                    )
                }
            }
        }

        item {
            Text("Aspect Ratio", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ratios.forEach { ratio ->
                    StudioChip(
                        text = ratio,
                        selected = selectedRatio == ratio,
                        onClick = { selectedRatio = ratio }
                    )
                }
            }
        }

        item {
            GenerateButton(
                text = "Generate Image (15 Credits)",
                isLoading = state is GenState.Loading,
                onClick = {
                    viewModel.generateImage(prompt, selectedStyle, selectedRatio)
                }
            )
        }

        // Result Viewer
        item {
            GenerationResultCard(
                state = state,
                defaultPreviewUrl = "https://picsum.photos/seed/${prompt.hashCode()}/800/800"
            )
        }
    }
}

// ==========================================
// 2. AI Text-to-Video Generator Screen
// ==========================================
@Composable
fun TextToVideoScreen(
    viewModel: GenerationViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var prompt by remember { mutableStateOf("Drone flight over futuristic neon skyscraper garden in 4K 60fps") }
    var duration by remember { mutableStateOf("10 Seconds") }
    var motion by remember { mutableStateOf("Cinematic Orbit") }
    val state by viewModel.videoGenState.collectAsState()

    val durations = listOf("5 Seconds", "10 Seconds", "15 Seconds")
    val motions = listOf("Cinematic Orbit", "Slow Dolly In", "Dynamic Pan", "FPV Drone")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("text_to_video_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Text-to-Video Generator",
                subtitle = "Generate cinematic multi-scene video storyboard from prompt",
                creditCost = 40L,
                engineTag = "Gemini 3.8 Video Director",
                outputType = "Real Storyboard & Production Script"
            )
        }

        item {
            PromptInputBox(
                value = prompt,
                onValueChange = { prompt = it },
                label = "Describe your scene, atmosphere, and action..."
            )
        }

        item {
            Text("Camera Motion", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(motions) { m ->
                    StudioChip(text = m, selected = motion == m, onClick = { motion = m })
                }
            }
        }

        item {
            Text("Duration", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                durations.forEach { d ->
                    StudioChip(text = d, selected = duration == d, onClick = { duration = d })
                }
            }
        }

        item {
            GenerateButton(
                text = "Generate Video Storyboard (40 Credits)",
                isLoading = state is GenState.Loading,
                onClick = {
                    viewModel.generateTextToVideo(prompt, duration, motion)
                }
            )
        }

        item {
            GenerationResultCard(
                state = state,
                defaultPreviewUrl = "https://picsum.photos/seed/video_${prompt.hashCode()}/1280/720"
            )
        }
    }
}

// ==========================================
// 3. Image-to-Video Generator Screen
// ==========================================
@Composable
fun ImageToVideoScreen(
    viewModel: GenerationViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var prompt by remember { mutableStateOf("Animate water ripples and glowing neon light reflections") }
    var motionType by remember { mutableStateOf("Fluid Zoom & Particle") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    val state by viewModel.videoGenState.collectAsState()

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            selectedImageUri = uri
        }
    }

    val motionPresets = listOf("Fluid Zoom & Particle", "Subtle Head Tilt", "Dramatic 3D Push", "Hyperlapse")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("image_to_video_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Image-to-Video Generator",
                subtitle = "Direct camera pans, depth zooms, and animation vectors from your image",
                creditCost = 35L,
                engineTag = "Gemini 3.8 Motion Engine",
                outputType = "Real Motion Vectors & Scene Directing"
            )
        }

        item {
            // Source Image Selector
            NeonCard {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF181F2D)),
                        contentAlignment = Alignment.Center
                    ) {
                        AsyncImage(
                            model = selectedImageUri ?: "https://picsum.photos/seed/source_img/800/800",
                            contentDescription = "Source Image",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (selectedImageUri != null) "Custom Image Selected" else "Sample: Neon Portrait.jpg",
                            fontSize = 12.sp,
                            color = CyberCyanSecondary,
                            fontWeight = FontWeight.SemiBold
                        )
                        Button(
                            onClick = {
                                photoPicker.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonVioletPrimary.copy(alpha = 0.25f),
                                contentColor = TextWhiteHighContrast
                            ),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Choose Photo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            PromptInputBox(
                value = prompt,
                onValueChange = { prompt = it },
                label = "Describe animation motions and vector dynamics..."
            )
        }

        item {
            Text("Animation Motion Preset", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(motionPresets) { preset ->
                    StudioChip(text = preset, selected = motionType == preset, onClick = { motionType = preset })
                }
            }
        }

        item {
            GenerateButton(
                text = "Animate Image (35 Credits)",
                isLoading = state is GenState.Loading,
                onClick = { viewModel.generateImageToVideo(prompt, motionType) }
            )
        }

        item {
            GenerationResultCard(
                state = state,
                defaultPreviewUrl = "https://picsum.photos/seed/animated_${prompt.hashCode()}/800/800"
            )
        }
    }
}

// ==========================================
// 4. AI Photo Enhancer Screen
// ==========================================
@Composable
fun PhotoEnhancerScreen(
    viewModel: GenerationViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var selectedMode by remember { mutableStateOf("Face Restoration") }
    var upscaleFactor by remember { mutableStateOf("4X Ultra HD") }
    var customImageUri by remember { mutableStateOf<Uri?>(null) }
    val state by viewModel.enhancerState.collectAsState()

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            customImageUri = uri
        }
    }

    val modes = listOf("Face Restoration", "Denoise & Clarity", "HDR Lighting", "Color Vitality")
    val upscales = listOf("2X HD", "4X Ultra HD", "8X Studio Pro")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("photo_enhancer_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "AI Photo Enhancer",
                subtitle = "Restore faces, upscale to 4K, and remove digital compression noise",
                creditCost = 20L,
                engineTag = "Gemini 3.8 Multimodal Vision",
                outputType = "Neural Restoration & Split Comparison"
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (customImageUri != null) "Custom Image Selected" else "Sample Photo Loaded",
                    fontSize = 12.sp,
                    color = CyberCyanSecondary,
                    fontWeight = FontWeight.SemiBold
                )
                Button(
                    onClick = {
                        photoPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonVioletPrimary.copy(alpha = 0.25f),
                        contentColor = TextWhiteHighContrast
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Select Your Photo", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            // Interactive Before/After comparison slider
            BeforeAfterComparisonSlider(
                beforeUrl = customImageUri?.toString() ?: "https://picsum.photos/seed/original_blurry/600/600",
                afterUrl = "https://picsum.photos/seed/enhanced_crisp/1200/1200"
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "◀ Drag slider horizontally to compare before and after AI enhancement ▶",
                fontSize = 11.sp,
                color = TextMutedSlate,
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Text("Enhancement Engine", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(modes) { m ->
                    StudioChip(text = m, selected = selectedMode == m, onClick = { selectedMode = m })
                }
            }
        }

        item {
            Text("Upscale Resolution", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                upscales.forEach { u ->
                    StudioChip(text = u, selected = upscaleFactor == u, onClick = { upscaleFactor = u })
                }
            }
        }

        item {
            GenerateButton(
                text = "Enhance & Upscale (20 Credits)",
                isLoading = state is GenState.Loading,
                onClick = { viewModel.enhancePhoto(selectedMode, upscaleFactor) }
            )
        }

        item {
            GenerationResultCard(
                state = state,
                defaultPreviewUrl = "https://picsum.photos/seed/enhanced_crisp/1200/1200"
            )
        }
    }
}

// ==========================================
// 5. AI Voice Generator Screen
// ==========================================
@Composable
fun VoiceGeneratorScreen(
    viewModel: GenerationViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var script by remember { mutableStateOf("Welcome creators! CreatorX AI gives you the power to produce viral shorts, voiceovers, and cinematic visuals in seconds.") }
    var selectedVoice by remember { mutableStateOf("Studio Narrator (Deep)") }
    var pitch by remember { mutableFloatStateOf(1.0f) }
    var speed by remember { mutableFloatStateOf(1.0f) }
    var isPlaying by remember { mutableStateOf(false) }

    val state by viewModel.voiceGenState.collectAsState()
    val voices = listOf("Studio Narrator (Deep)", "Energetic Podcaster", "ASMR Whisper", "Cinematic Trailer")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("voice_generator_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "AI Voice Generator",
                subtitle = "Human-like neural speech synthesis with expressive cadence",
                creditCost = 15L,
                engineTag = "Gemini TTS Preview",
                outputType = "Real Speech Synthesis & Audio Track"
            )
        }

        item {
            PromptInputBox(
                value = script,
                onValueChange = { script = it },
                label = "Enter text or script for voiceover synthesis..."
            )
        }

        item {
            Text("Voice Timbre Profile", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(voices) { v ->
                    StudioChip(text = v, selected = selectedVoice == v, onClick = { selectedVoice = v })
                }
            }
        }

        item {
            NeonCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Pitch Adjust: ${"%.1f".format(pitch)}x", fontSize = 13.sp, color = TextWhiteHighContrast)
                    Slider(
                        value = pitch,
                        onValueChange = { pitch = it },
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = NeonVioletPrimary,
                            activeTrackColor = NeonVioletPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Pacing Speed: ${"%.1f".format(speed)}x", fontSize = 13.sp, color = TextWhiteHighContrast)
                    Slider(
                        value = speed,
                        onValueChange = { speed = it },
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = CyberCyanSecondary,
                            activeTrackColor = CyberCyanSecondary
                        )
                    )
                }
            }
        }

        item {
            GenerateButton(
                text = "Synthesize Voice Track (15 Credits)",
                isLoading = state is GenState.Loading,
                onClick = { viewModel.generateVoice(script, selectedVoice, pitch, speed) }
            )
        }

        // Voice playback card
        item {
            if (state is GenState.Success) {
                NeonCard(borderColor = CyberCyanSecondary) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("AUDIO TRACK READY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CyberCyanSecondary)
                            IconButton(
                                onClick = { isPlaying = !isPlaying },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(CyberCyanSecondary)
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Stop",
                                    tint = Color.Black
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = (state as GenState.Success<String>).data,
                            fontSize = 13.sp,
                            color = TextWhiteHighContrast
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// 6. TikTok & YouTube Shorts Creator Screen
// ==========================================
@Composable
fun ShortsCreatorScreen(
    viewModel: GenerationViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var topic by remember { mutableStateOf("3 AI tools that will save you 10 hours this week") }
    var platform by remember { mutableStateOf("TikTok & Shorts") }
    val state by viewModel.shortsGenState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("shorts_creator_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Shorts & TikTok Creator",
                subtitle = "Generate viral 9:16 vertical hooks, scripts, and pacing blueprints",
                creditCost = 25L,
                engineTag = "Gemini 3.8 Viral Engine",
                outputType = "Real 9:16 Script, Hook & Captions"
            )
        }

        item {
            PromptInputBox(
                value = topic,
                onValueChange = { topic = it },
                label = "What is your Short topic or niche idea?"
            )
        }

        item {
            GenerateButton(
                text = "Generate Viral Blueprint (25 Credits)",
                isLoading = state is GenState.Loading,
                onClick = { viewModel.generateShorts(topic, platform) }
            )
        }

        item {
            GenerationResultCard(
                state = state,
                defaultPreviewUrl = "https://picsum.photos/seed/shorts_${topic.hashCode()}/720/1280"
            )
        }
    }
}

// ==========================================
// 7. Video Editor with Subtitles & Music Screen
// ==========================================
@Composable
fun VideoEditorScreen(
    viewModel: GenerationViewModel,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var videoTopic by remember { mutableStateOf("Day in the life of a tech creator in Tokyo") }
    var musicGenre by remember { mutableStateOf("Cyber Lo-Fi Chill") }
    val state by viewModel.editorGenState.collectAsState()

    val genres = listOf("Cyber Lo-Fi Chill", "Cinematic Orchestral", "Electronic Trap", "Acoustic Warmth")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
            .padding(16.dp)
            .testTag("video_editor_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ToolHeader(
                title = "Video Editor Studio",
                subtitle = "Automated subtitle synchronization & curated background soundtracking",
                creditCost = 20L,
                engineTag = "Gemini 3.8 Timeline Engine",
                outputType = "Real Subtitle SRT Timecodes & Music Sync"
            )
        }

        item {
            PromptInputBox(
                value = videoTopic,
                onValueChange = { videoTopic = it },
                label = "Video topic or voice transcript..."
            )
        }

        item {
            Text("Background Music Vibe", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextWhiteHighContrast)
            Spacer(modifier = Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(genres) { g ->
                    StudioChip(text = g, selected = musicGenre == g, onClick = { musicGenre = g })
                }
            }
        }

        item {
            GenerateButton(
                text = "Generate Subtitles & Soundtrack (20 Credits)",
                isLoading = state is GenState.Loading,
                onClick = { viewModel.generateVideoEditorProject(videoTopic, musicGenre) }
            )
        }

        item {
            GenerationResultCard(
                state = state,
                defaultPreviewUrl = "https://picsum.photos/seed/timeline_${videoTopic.hashCode()}/1280/720"
            )
        }
    }
}

// Reusable Helper Composables
@Composable
fun ToolHeader(
    title: String,
    subtitle: String,
    creditCost: Long,
    engineTag: String = "Gemini 3.8 Flash",
    outputType: String = "Real AI Inference"
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhiteHighContrast
            )
            CreditCostBadge(cost = creditCost)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = CyberCyanSecondary.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyanSecondary.copy(alpha = 0.3f))
            ) {
                Text(
                    text = engineTag,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = CyberCyanSecondary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = NeonVioletPrimary.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonVioletPrimary.copy(alpha = 0.3f))
            ) {
                Text(
                    text = outputType,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonVioletPrimary,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = subtitle,
            fontSize = 13.sp,
            color = TextMutedSlate
        )
    }
}

@Composable
fun PromptInputBox(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .testTag("prompt_input_field"),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color(0xFF111622),
            unfocusedContainerColor = Color(0xFF0E131C),
            focusedBorderColor = NeonVioletPrimary,
            unfocusedBorderColor = Color(0xFF222B3D),
            focusedTextColor = TextWhiteHighContrast,
            unfocusedTextColor = TextWhiteHighContrast
        ),
        placeholder = {
            Text(label, fontSize = 13.sp, color = TextMutedSlate)
        }
    )
}

@Composable
fun StudioChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .border(
                1.dp,
                if (selected) NeonVioletPrimary else Color(0xFF222B3D),
                RoundedCornerShape(12.dp)
            ),
        color = if (selected) NeonVioletPrimary.copy(alpha = 0.25f) else Color(0xFF131824)
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else TextMutedSlate,
            fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun GenerateButton(text: String, isLoading: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("generate_action_button"),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = NeonVioletPrimary,
            contentColor = Color.White
        ),
        enabled = !isLoading
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = Color.White,
                strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text("AI Processing with Gemini...", fontWeight = FontWeight.SemiBold)
        } else {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
fun GenerationResultCard(
    state: GenState<String>,
    defaultPreviewUrl: String? = null
) {
    val clipboardManager = LocalClipboardManager.current
    when (state) {
        is GenState.Loading -> {
            NeonCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(
                        color = NeonVioletPrimary,
                        modifier = Modifier.size(36.dp),
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = state.stage,
                        color = CyberCyanSecondary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
        is GenState.Success -> {
            NeonCard(borderColor = CyberCyanSecondary.copy(alpha = 0.6f)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "GENERATION COMPLETE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = CyberCyanSecondary,
                            letterSpacing = 1.sp
                        )
                        IconButton(
                            onClick = { clipboardManager.setText(AnnotatedString(state.data)) },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Copy",
                                tint = TextMutedSlate,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    if (!defaultPreviewUrl.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF161C28))
                        ) {
                            AsyncImage(
                                model = defaultPreviewUrl,
                                contentDescription = "Generated Preview",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = state.data,
                        fontSize = 13.sp,
                        color = TextWhiteHighContrast
                    )
                }
            }
        }
        is GenState.Error -> {
            NeonCard(borderColor = MaterialTheme.colorScheme.error) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "GENERATION NOTICE",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.error
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = state.message,
                        fontSize = 13.sp,
                        color = TextWhiteHighContrast
                    )
                }
            }
        }
        GenState.Idle -> Unit
    }
}
