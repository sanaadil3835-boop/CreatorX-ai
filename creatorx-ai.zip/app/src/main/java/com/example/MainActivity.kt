package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.repository.AiStudioRepository
import com.example.data.repository.FirestoreUserRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.navigation.AppNavigation
import com.example.ui.theme.CreatorXTheme
import com.example.ui.theme.ObsidianDarkBackground
import com.example.ui.viewmodel.GenerationViewModel
import com.example.ui.viewmodel.StudioViewModel
import com.example.util.configureAppCheck
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI, ViewModels, or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            CreatorXTheme {
                CreatorXAppRoot()
            }
        }
    }
}

@Composable
fun CreatorXAppRoot() {
    val context = LocalContext.current
    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianDarkBackground)
    ) {
        if (currentUser == null) {
            AuthScreen(
                onAuthSuccess = {
                    currentUser = Firebase.auth.currentUser
                }
            )
        } else {
            val uid = currentUser!!.uid
            // Key by uid to ensure state resets when signing out or switching accounts
            key(uid) {
                val userRepository = remember(uid) { FirestoreUserRepository(context) }
                val aiRepository = remember { AiStudioRepository() }

                val studioViewModel = remember(uid) { StudioViewModel(userRepository) }
                val genViewModel = remember(uid) { GenerationViewModel(aiRepository, userRepository) }

                AppNavigation(
                    studioViewModel = studioViewModel,
                    genViewModel = genViewModel,
                    onSignOutComplete = {
                        currentUser = null
                    }
                )
            }
        }
    }
}
