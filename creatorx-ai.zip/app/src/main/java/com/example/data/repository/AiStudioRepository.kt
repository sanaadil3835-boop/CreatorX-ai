package com.example.data.repository

import android.graphics.Bitmap
import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.TextPart
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

private const val TAG = "AiStudioRepository"

class AiStudioRepository {

    // Lazy initialization prevents early startup evaluation
    private val textModel by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    private val imageModel by lazy {
        Firebase.ai.generativeModel("gemini-nano-banana-2.1")
    }

    suspend fun enhancePrompt(rawPrompt: String, toolContext: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val systemPrompt = """
                You are a world-class prompt engineer for CreatorX AI Studio.
                Task: Enhance the user's prompt for the '$toolContext' tool.
                Add vivid visual details, cinematic camera angles, atmospheric lighting, rendering engine keywords (e.g. Unreal Engine 5, Octane Render, 8K Photorealistic), and styling nuances while preserving their original creative intent.
                Output ONLY the enhanced prompt text directly without any preface or quotation marks.
                User Prompt: $rawPrompt
            """.trimIndent()

            val response = withTimeout(45_000L) {
                textModel.generateContent(systemPrompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("AI model returned an empty prompt enhancement."))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Prompt enhancement failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateVideoStoryboard(scriptPrompt: String, duration: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val prompt = """
                You are an executive video director at CreatorX AI.
                Create a detailed cinematic video production breakdown for:
                Duration: $duration
                Prompt: $scriptPrompt

                Format as:
                🎬 SCENE 1 (0:00 - 0:05):
                - Visual Description: [detailed visuals]
                - Camera Motion: [e.g. Slow Dolly In, 35mm Anamorphic, Orbit]
                - Lighting: [e.g. Neon Volumetric Rim Light, Golden Hour]
                - Sound FX: [audio cues]

                🎬 SCENE 2:
                ...
                Output in clear, clean markdown with emojis for creator presentation.
            """.trimIndent()

            val response = withTimeout(55_000L) {
                textModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Failed to generate storyboard"))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Video storyboard failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateShortsPlan(topic: String, platform: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val prompt = """
                You are a top viral content strategist for $platform and TikTok.
                Generate a high-converting viral 9:16 Short production blueprint for topic: "$topic".

                Include:
                🔥 1. THE 3-SECOND HOOK (Visual + Spoken text that stops the scroll)
                ⚡ 2. THE ENGAGEMENT BODY (Rapid pacing, high value points)
                🎯 3. CALL TO ACTION & VIRAL LOOP (Encouraging comments, shares, rewatches)
                💬 4. ON-SCREEN SUBTITLE CAPTIONS (Bold punchy words with emoji triggers)
                🎵 5. TRENDING AUDIO RECOMMENDATION (Tempo, genre, sound style)
                #️⃣ 6. VIRAL HASHTAGS (Top 8 targeted tags)
            """.trimIndent()

            val response = withTimeout(55_000L) {
                textModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Failed to generate shorts script"))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Shorts generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateSubtitlesAndMusic(videoTopic: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val prompt = """
                Generate a professional Subtitle Timeline & Audio Track Recommendation for video: "$videoTopic".
                Provide:
                1. Synchronized Subtitles (SRT format with timestamps like 00:00:00 --> 00:00:03).
                2. Recommended Background Track (BPM, Mood, Instrumentation, Ducking level).
            """.trimIndent()

            val response = withTimeout(50_000L) {
                textModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Empty subtitle output"))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Subtitles generation failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateVoiceScript(textInput: String, voiceName: String, tone: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val prompt = """
                Format and refine the following text for AI Voice Narration.
                Voice Profile: $voiceName ($tone tone).
                Add SSML tags or pronunciation guides (pauses [pause 0.5s], emphasis *word*, intonation) to make it sound incredibly human and professional.
                Script:
                $textInput
            """.trimIndent()

            val response = withTimeout(45_000L) {
                textModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Empty voice script output"))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Voice script failed", e)
            Result.failure(e)
        }
    }

    suspend fun analyzeImageWithGemini(bitmap: Bitmap, prompt: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val contentPayload = Content(
                parts = listOf(
                    ImagePart(bitmap),
                    TextPart(prompt)
                )
            )

            val response = withTimeout(60_000L) {
                textModel.generateContent(listOf(contentPayload))
            }
            val text = response.text?.trim()
            if (!text.isNullOrBlank()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("No analysis returned for image."))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image analysis failed", e)
            Result.failure(e)
        }
    }

    suspend fun generateImageWithGemini(prompt: String): Result<Bitmap> = withContext(Dispatchers.IO) {
        try {
            val response = withTimeout(60_000L) {
                imageModel.generateContent(prompt)
            }
            val bitmap = response.candidates.firstOrNull()?.content?.parts
                ?.filterIsInstance<ImagePart>()
                ?.firstOrNull()?.image

            if (bitmap != null) {
                Result.success(bitmap)
            } else {
                val msg = response.text ?: "Image generation completed without bitmap data."
                Result.failure(IllegalStateException(msg))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Image generation error: ${e.message}", e)
            Result.failure(e)
        }
    }
}
