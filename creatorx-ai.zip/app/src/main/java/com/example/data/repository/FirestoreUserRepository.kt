package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.CreationItem
import com.example.data.model.CreditTransaction
import com.example.data.model.PromptTemplate
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class FirestoreUserRepository(private val db: FirebaseFirestore) {

    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private val auth = Firebase.auth

    fun getCurrentUserId(): String? = auth.currentUser?.uid

    fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    suspend fun getOrCreateUserProfile(): Result<UserProfile> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Not signed in"))
        val uid = user.uid
        val docRef = db.collection("users").document(uid)

        return try {
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                val profile = snapshot.toObject(UserProfile::class.java)
                    ?: UserProfile(userId = uid, displayName = user.displayName ?: "Creator")
                Result.success(profile)
            } else {
                val referralCode = uid.take(4).uppercase() + (1000..9999).random()
                val isOwnerAdmin = user.email?.equals("hamdh3835@gmail.com", ignoreCase = true) == true
                val newProfile = UserProfile(
                    userId = uid,
                    displayName = user.displayName ?: "Creator",
                    email = user.email ?: "",
                    photoUrl = user.photoUrl?.toString(),
                    credits = 250L,
                    isPremium = false,
                    subscriptionTier = "Free",
                    referralCode = referralCode,
                    streakDays = 1L,
                    lastDailyClaim = null,
                    role = if (isOwnerAdmin) "admin" else "user"
                )
                val payload = mapOf(
                    "userId" to uid,
                    "displayName" to newProfile.displayName,
                    "email" to newProfile.email,
                    "photoUrl" to newProfile.photoUrl,
                    "credits" to newProfile.credits,
                    "isPremium" to newProfile.isPremium,
                    "subscriptionTier" to newProfile.subscriptionTier,
                    "referralCode" to newProfile.referralCode,
                    "referredBy" to null,
                    "streakDays" to newProfile.streakDays,
                    "lastDailyClaim" to null,
                    "role" to newProfile.role,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).filterValues { it != null }

                docRef.set(payload).await()

                // Welcome credits transaction
                addTransaction(
                    userId = uid,
                    amount = 250L,
                    type = "subscription_grant",
                    description = "CreatorX Studio welcome bonus credits"
                )

                Result.success(newProfile)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed getOrCreateUserProfile", e)
            Result.failure(e)
        }
    }

    fun observeUserProfile(): Flow<UserProfile?> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("users").document(uid)
                .snapshots()
                .map { it.toObject(UserProfile::class.java) }
                .catch { e ->
                    if (e is CancellationException) throw e
                    Log.e("UserRepository", "Error observing profile", e)
                    emit(null)
                }
        )
    }

    suspend fun claimDailyCredits(): Result<Long> {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid)

        return try {
            val snapshot = docRef.get().await()
            val profile = snapshot.toObject(UserProfile::class.java)
                ?: return Result.failure(IllegalStateException("Profile not found"))

            val lastClaim = profile.lastDailyClaim?.toDate()
            val now = Date()
            if (lastClaim != null) {
                val diffHours = (now.time - lastClaim.time) / (1000 * 60 * 60)
                if (diffHours < 20) {
                    val remainingHours = 20 - diffHours
                    return Result.failure(IllegalStateException("Daily streak already claimed today! Check back in $remainingHours hours."))
                }
            }

            val newStreak = (profile.streakDays + 1).coerceAtMost(365)
            val bonusCredits = 50L

            docRef.update(
                mapOf(
                    "credits" to FieldValue.increment(bonusCredits),
                    "streakDays" to newStreak,
                    "lastDailyClaim" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            addTransaction(
                userId = uid,
                amount = bonusCredits,
                type = "daily_streak",
                description = "Day $newStreak daily streak bonus (+50 credits)"
            )

            Result.success(bonusCredits)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to claim daily credits", e)
            Result.failure(e)
        }
    }

    suspend fun applyReferralCode(code: String): Result<Long> {
        val uid = requireUserId()
        val cleanCode = code.trim().uppercase()
        if (cleanCode.isBlank()) return Result.failure(IllegalArgumentException("Code cannot be empty"))

        val userDoc = db.collection("users").document(uid)
        return try {
            val current = userDoc.get().await().toObject(UserProfile::class.java)
            if (current?.referredBy != null) {
                return Result.failure(IllegalStateException("You have already used a referral code!"))
            }
            if (current?.referralCode.equals(cleanCode, ignoreCase = true)) {
                return Result.failure(IllegalStateException("You cannot refer yourself!"))
            }

            val bonus = 100L
            userDoc.update(
                mapOf(
                    "credits" to FieldValue.increment(bonus),
                    "referredBy" to cleanCode,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            addTransaction(
                userId = uid,
                amount = bonus,
                type = "referral_bonus",
                description = "Referral code reward '$cleanCode' (+100 credits)"
            )

            Result.success(bonus)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to apply referral code", e)
            Result.failure(e)
        }
    }

    suspend fun saveCreation(
        title: String,
        type: String,
        prompt: String,
        mediaUrl: String,
        creditCost: Long,
        aspectRatio: String? = null,
        stylePreset: String? = null,
        voiceName: String? = null
    ): Result<CreationItem> {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        val creationDoc = userDoc.collection("creations").document()

        return try {
            // Deduct credits if cost > 0
            if (creditCost > 0) {
                userDoc.update(
                    mapOf(
                        "credits" to FieldValue.increment(-creditCost),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()

                addTransaction(
                    userId = uid,
                    amount = -creditCost,
                    type = "creation_cost",
                    description = "$type generation: $title (-$creditCost credits)"
                )
            }

            val payload = mapOf(
                "userId" to uid,
                "title" to title,
                "type" to type,
                "prompt" to prompt,
                "mediaUrl" to mediaUrl,
                "thumbnailUrl" to null,
                "aspectRatio" to aspectRatio,
                "stylePreset" to stylePreset,
                "voiceName" to voiceName,
                "status" to "completed",
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).filterValues { it != null }

            creationDoc.set(payload).await()

            val creationItem = CreationItem(
                id = creationDoc.id,
                userId = uid,
                title = title,
                type = type,
                prompt = prompt,
                mediaUrl = mediaUrl,
                aspectRatio = aspectRatio,
                stylePreset = stylePreset,
                voiceName = voiceName,
                status = "completed",
                createdAt = Timestamp.now()
            )
            Result.success(creationItem)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to save creation", e)
            Result.failure(e)
        }
    }

    fun observeUserCreations(): Flow<List<CreationItem>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("users").document(uid).collection("creations")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { it.toObjects(CreationItem::class.java) }
                .catch { e ->
                    if (e is CancellationException) throw e
                    Log.e("UserRepository", "Failed to observe creations", e)
                    emit(emptyList())
                }
        )
    }

    fun observeUserTransactions(): Flow<List<CreditTransaction>> = flow {
        val uid = requireUserId()
        emitAll(
            db.collection("users").document(uid).collection("transactions")
                .orderBy("createdAt", Query.Direction.DESCENDING)
                .snapshots()
                .map { it.toObjects(CreditTransaction::class.java) }
                .catch { e ->
                    if (e is CancellationException) throw e
                    Log.e("UserRepository", "Failed to observe transactions", e)
                    emit(emptyList())
                }
        )
    }

    suspend fun upgradeSubscription(tier: String): Result<Unit> {
        val uid = requireUserId()
        val userDoc = db.collection("users").document(uid)
        return try {
            val grantCredits = if (tier == "Studio Max") 2000L else 750L
            userDoc.update(
                mapOf(
                    "isPremium" to true,
                    "subscriptionTier" to tier,
                    "credits" to FieldValue.increment(grantCredits),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            addTransaction(
                userId = uid,
                amount = grantCredits,
                type = "subscription_grant",
                description = "Upgraded to $tier: +$grantCredits bonus credits"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed to upgrade subscription", e)
            Result.failure(e)
        }
    }

    // Curated Prompt Library
    fun observePromptLibrary(): Flow<List<PromptTemplate>> = flow {
        emitAll(
            db.collection("prompts")
                .snapshots()
                .map { it.toObjects(PromptTemplate::class.java) }
                .catch { e ->
                    if (e is CancellationException) throw e
                    Log.e("UserRepository", "Failed to observe prompts", e)
                    emit(emptyList())
                }
        )
    }

    // Admin grant credits
    suspend fun adminGrantCredits(targetUserId: String, creditsToAdd: Long): Result<Unit> {
        return try {
            val docRef = db.collection("users").document(targetUserId)
            docRef.update(
                mapOf(
                    "credits" to FieldValue.increment(creditsToAdd),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()

            addTransaction(
                userId = targetUserId,
                amount = creditsToAdd,
                type = "admin_gift",
                description = "Admin manual credit grant (+${creditsToAdd} credits)"
            )
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e("UserRepository", "Failed admin grant credits", e)
            Result.failure(e)
        }
    }

    private suspend fun addTransaction(userId: String, amount: Long, type: String, description: String) {
        try {
            val txDoc = db.collection("users").document(userId).collection("transactions").document()
            val payload = mapOf(
                "userId" to userId,
                "amount" to amount,
                "type" to type,
                "description" to description,
                "createdAt" to FieldValue.serverTimestamp()
            )
            txDoc.set(payload).await()
        } catch (e: Exception) {
            Log.w("UserRepository", "Failed to record transaction", e)
        }
    }
}
