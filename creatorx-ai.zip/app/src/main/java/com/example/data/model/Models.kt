package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
    val userId: String = "",
    val displayName: String = "",
    val email: String = "",
    val photoUrl: String? = null,
    val credits: Long = 250L,
    val isPremium: Boolean = false,
    val subscriptionTier: String = "Free",
    val referralCode: String = "",
    val referredBy: String? = null,
    val streakDays: Long = 1L,
    val lastDailyClaim: Timestamp? = null,
    val role: String = "user",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CreationItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val type: String = "image", // image, text_to_video, image_to_video, photo_enhancer, voice, short, video_editor
    val prompt: String = "",
    val mediaUrl: String = "",
    val thumbnailUrl: String? = null,
    val aspectRatio: String? = null,
    val stylePreset: String? = null,
    val voiceName: String? = null,
    val status: String = "completed",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class CreditTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val amount: Long = 0L,
    val type: String = "daily_streak", // daily_streak, referral_bonus, creation_cost, subscription_grant, admin_gift
    val description: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PromptTemplate(
    @DocumentId val id: String = "",
    val title: String = "",
    val category: String = "",
    val toolTarget: String = "image",
    val prompt: String = "",
    val negativePrompt: String? = null,
    val tags: List<String> = emptyList(),
    val likesCount: Long = 0L,
    @ServerTimestamp val createdAt: Timestamp? = null
)

enum class StudioTool(
    val id: String,
    val title: String,
    val subtitle: String,
    val creditCost: Long,
    val iconName: String
) {
    IMAGE_GEN("image", "AI Image Generator", "Text-to-Image in 1:1, 9:16, 16:9 with styles", 15L, "image"),
    TEXT_TO_VIDEO("text_to_video", "Text-to-Video", "Generate cinematic video scenes from script", 40L, "videocam"),
    IMAGE_TO_VIDEO("image_to_video", "Image-to-Video", "Bring still photos to life with camera motions", 35L, "motion_photos_on"),
    PHOTO_ENHANCER("photo_enhancer", "AI Photo Enhancer", "Face restoration, 4K upscale, and denoise", 20L, "auto_fix_high"),
    VOICE_GEN("voice", "AI Voice Generator", "Studio text-to-speech with multiple accents", 15L, "record_voice_over"),
    SHORTS_CREATOR("short", "Shorts & TikTok Creator", "Viral hooks, 9:16 formatting, and pacing", 25L, "smart_display"),
    VIDEO_EDITOR("video_editor", "Video Editor Studio", "Subtitles, background music, and timing", 20L, "movie_edit"),
    PROMPT_LIBRARY("prompts", "Prompt Library", "Top trending prompts and viral formulas", 0L, "menu_book"),
    USER_PROFILE("profile", "Creator Profile", "Creations showcase and portfolio", 0L, "account_circle"),
    DAILY_CREDITS("credits", "Daily Free Credits", "Earn +50 daily streak and referral rewards", 0L, "monetization_on"),
    PREMIUM_PLANS("subscriptions", "Premium Plans", "Unlimited access and priority processing", 0L, "star"),
    ADMIN_DASHBOARD("admin", "Admin Dashboard", "System status, telemetry, and user management", 0L, "admin_panel_settings")
}
