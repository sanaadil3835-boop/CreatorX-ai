package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.CreationItem
import com.example.data.model.CreditTransaction
import com.example.data.model.PromptTemplate
import com.example.data.model.StudioTool
import com.example.data.model.UserProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context verifies app_name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("CreatorX AI", appName)
    }

    @Test
    fun `verify all 12 studio tools exist with valid costs`() {
        val tools = StudioTool.entries
        assertEquals(12, tools.size)

        val imageTool = StudioTool.IMAGE_GEN
        assertEquals("image", imageTool.id)
        assertEquals(15L, imageTool.creditCost)

        val videoTool = StudioTool.TEXT_TO_VIDEO
        assertEquals("text_to_video", videoTool.id)
        assertEquals(40L, videoTool.creditCost)

        val voiceTool = StudioTool.VOICE_GEN
        assertEquals(15L, voiceTool.creditCost)

        val adminTool = StudioTool.ADMIN_DASHBOARD
        assertEquals(0L, adminTool.creditCost)
    }

    @Test
    fun `verify user profile defaults`() {
        val profile = UserProfile(
            userId = "user_test_123",
            displayName = "Creator Test",
            email = "test@creatorx.ai"
        )
        assertEquals(250L, profile.credits)
        assertEquals(false, profile.isPremium)
        assertEquals("Free", profile.subscriptionTier)
        assertEquals("user", profile.role)
    }

    @Test
    fun `verify creation item and transaction data models`() {
        val creation = CreationItem(
            id = "cr_1",
            userId = "user_test_123",
            title = "Cyber City",
            type = "image",
            prompt = "Cyberpunk city",
            mediaUrl = "https://example.com/art.png"
        )
        assertNotNull(creation.id)
        assertEquals("image", creation.type)

        val tx = CreditTransaction(
            id = "tx_1",
            userId = "user_test_123",
            amount = 50L,
            type = "daily_streak",
            description = "Daily bonus"
        )
        assertTrue(tx.amount > 0)
    }
}
