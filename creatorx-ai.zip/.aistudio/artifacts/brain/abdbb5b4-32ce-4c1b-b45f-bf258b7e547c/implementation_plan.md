# CreatorX AI - Native Android AI Creator Studio

A next-generation mobile creation powerhouse that equips digital creators, influencers, and artists with state-of-the-art AI generation tools, video/short-form editing, voice synthesis, credit management, and cloud collaboration.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural parameters have been established based on your selections:

- **Confirmed AI Engine**: **Firebase AI Logic with Google Gemini** (`gemini-3.8-flash`, `gemini-nano-banana-2.1`, and Gemini TTS preview). All inference calls leverage App Check attestation and transparent state handling without insecure client API keys.
- **Confirmed Cloud Architecture**: **Firebase Authentication & Cloud Firestore** with Google Sign-In via Jetpack `CredentialManager`. Secure per-user isolation, real-time sync, and hardened security rules.
- **Confirmed Visual Direction**: **Neon Studio** featuring an obsidian dark theme (`#0B0E14`), deep charcoal elevated surfaces (`#161B26`), electric violet (`#8B5CF6`), and radiant cyber cyan (`#06B6D4`) accents, built strictly on Material 3 design tokens.

---

## 1. Overview & Core Concept

**CreatorX AI** is designed as an all-in-one mobile creative suite tailored for content creators, social media influencers (TikTok, YouTube Shorts, Reels), digital marketers, and storytellers. It consolidates 12 essential creative engines into a unified, responsive Android experience:

1. **AI Image Generator**: Text-to-image synthesis with artistic style presets (Cinematic, Photorealistic, Cyberpunk, 3D Render, Anime), custom aspect ratios (1:1, 9:16, 16:9), and negative prompts.
2. **AI Text-to-Video Generator**: Script-to-video scene prompting with camera motion control, atmospheric lighting, and storyboard previews.
3. **Image-to-Video Generator**: Animate static photos, character portraits, and concept art with dynamic camera zoom, motion vectors, and particle effects.
4. **AI Photo Enhancer**: Ultra-HD face restoration, 2x/4x resolution upscaling, denoising, and HDR lighting correction with an interactive before/after split slider.
5. **AI Voice Generator**: Text-to-speech studio with multi-accent voice profiles (Studio Narrator, Energetic Podcaster, ASMR, Cinematic Trailer), pitch/cadence sliders, and real-time audio playback.
6. **TikTok & YouTube Shorts Creator**: 9:16 viral short builder, AI hook generation, trending sound suggestions, and pacing guides.
7. **Video Editor Studio**: Clip timeline sequencer, automatic subtitle styling, background ambient music selection, and preview scrubber.
8. **Prompt Library**: Curated, searchable library of top-performing prompts across photography, 3D art, video hooks, and voice scripts, with one-tap transfer to generators.
9. **User Accounts & Profiles**: Google Sign-In profile, creator portfolio gallery of generated assets, storage statistics, and account settings.
10. **Daily Free Credits & Referral Rewards**: Daily claim streak counter (+50 free credits every 24h), unique referral invite code (+100 credits for inviter/invitee), and credit transaction history.
11. **Premium Subscriptions**: Tiered Creator Pro and Studio Max passes with unlimited fast-track generations, 4K rendering exports, watermarking removal, and priority rendering queues.
12. **Admin Dashboard**: System telemetry, AI provider status check, user credit grant controls, generation metrics, and feature flag management.

---

## 2. User Experience & Visual Design

### Key User Flows

```
┌────────────────────────────────────────────────────────┐
│                   App Launch & Auth                    │
│    (Google Sign-In Auth Gate / Silent Auto Sign-In)    │
└──────────────────────────┬─────────────────────────────┘
                           │
                           ▼
┌────────────────────────────────────────────────────────┐
│               CreatorX Studio Home Hub                 │
│  • Daily Credit Claim Banner (+50 Credits Streak)      │
│  • Quick Launch Studio Carousel (12 AI Tools)          │
│  • Trending Community Inspirations & Recent Drafts     │
└──────┬───────────────────┬───────────────────┬─────────┘
       │                   │                   │
       ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────────┐
│ Studio Tools │   │ Prompt Vault │   │ Profile & Wallet │
│ • Text-to-Img│   │ • Search     │   │ • Credits Ledger │
│ • Video Gen  │   │ • Categories │   │ • Referrals      │
│ • Enhancer   │   │ • 1-Tap Copy │   │ • Pro Upgrades   │
│ • Voice TTS  │   │   & Inject   │   │ • Admin Console  │
│ • Shorts Lab │   └──────────────┘   └──────────────────┘
│ • Timeline Ed│
└──────────────┘
```

### Visual Identity & Theme Tokens

- **Aesthetic**: Neon Obsidian Studio — darkroom creative atmosphere with sharp glowing neon micro-indicators and polished glassmorphic surfaces.
- **Color Palette**:
  - `Background`: Deep Obsidian (`#0A0D14`)
  - `Surface`: Elevated Charcoal (`#131822`)
  - `SurfaceVariant`: Translucent Graphite (`#1E2534`)
  - `Primary`: Electric Violet (`#8B5CF6`)
  - `Secondary`: Radiant Cyber Cyan (`#06B6D4`)
  - `Tertiary`: Neon Amber (`#F59E0B` for Credits & Streak badges)
  - `Success`: Emerald Green (`#10B981`)
  - `Error`: Hot Coral (`#EF4444`)
  - `OnPrimary` / `OnSurface`: High-contrast pure white (`#F8FAFC`) and muted silver (`#94A3B8`)
- **Typography**: Clean modern sans-serif scale with bold display headers, monospaced prompts and parameter badges, and crisp body styling.
- **Component Styling**:
  - Rounded cards (16dp-24dp) with subtle 1dp glowing borders (`Color.White.copy(alpha = 0.08f)`).
  - Floating Studio action bar with haptic ripple indicators.
  - Interactive split-slider for Photo Enhancer before/after comparison.
  - Responsive waveform visualizer for AI Voice generation.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Firebase AI Logic with App Check over Client API Keys**
  - *Chosen Approach*: All generative text, prompt enhancement, script expansion, and image synthesis workflows route through `Firebase.ai` backed by App Check attestation.
  - *Why*: Eliminates security vulnerabilities associated with packaging static API keys in mobile APKs, while guaranteeing real Gemini 3.8 Flash inference.
  - *Fallback/Transparent Reporting*: If the backend provider or App Check debug attestation is unprovisioned, the studio displays explicit status diagnostics with setup guidance rather than silently failing or showing fabricated mock outputs.

- **Decision 2: Cloud Firestore with Custom Database Instance ID**
  - *Chosen Approach*: User profile records, credit ledgers, referral codes, creation logs, and saved prompt bookmarks are persisted in Cloud Firestore (`context.getString(R.string.firestore_database_id)`).
  - *Why*: Enables durable sync across device installs, guarantees that earned daily credits and saved creations are preserved, and enforces user data isolation.

- **Decision 3: Zero-Mock Real Integrations & Play Policy Compliance**
  - *Chosen Approach*: Real image loading via Coil, real audio playback engine, Android Photo Picker (`PickVisualMedia`) without broad external storage permissions, and genuine credential authentication.

---

## 4. Technical Architecture & Data Strategy

### System & Component Architecture

```
┌────────────────────────────────────────────────────────────────────────┐
│                             UI Layer                                   │
│  MainActivity  ──►  AppNavigation  ──►  Scaffold & NavigationRail/Bar  │
│                                                                        │
│  ┌───────────────────────┬──────────────────────┬───────────────────┐  │
│  │   Studio Hub Screen   │   AI Tool Studios    │  Profile & Admin  │  │
│  │ • Daily Streak Banner │ • Image Generator    │ • Credit Wallet   │  │
│  │ • Tool Grid & Feeds   │ • Video / Shorts Lab │ • Referrals       │  │
│  │ • Quick Prompts       │ • Voice & Enhancer   │ • Pro Tier Plans  │  │
│  │                       │ • Editor Studio      │ • Admin Telemetry │  │
│  └───────────────────────┴──────────────────────┴───────────────────┘  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ StateFlow / Events
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                         Presentation / ViewModels                      │
│   • StudioViewModel     • AuthViewModel        • GenerationViewModel   │
│   • WalletViewModel     • AdminViewModel       • PromptVaultViewModel  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                            Repository Layer                            │
│  ┌───────────────────────────────┬──────────────────────────────────┐  │
│  │      AiStudioRepository       │      FirestoreUserRepository     │  │
│  │  • Firebase.ai (Gemini 3.8)   │  • UserProfile & Daily Claim     │  │
│  │  • Imagen / Banana Generation │  • Credit Transactions & Ledger  │  │
│  │  • Multimodal Vision Analysis │  • Referrals & Saved Prompts     │  │
│  └───────────────────────────────┴──────────────────────────────────┘  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        Backend / Infrastructure                        │
│   Firebase Auth (Google) │ Cloud Firestore │ Firebase AI Logic (Gemini)│
└────────────────────────────────────────────────────────────────────────┘
```

### Data Models & Schema Overview

- **`users/{userId}`**:
  - `userId: String` (Primary Key)
  - `displayName: String`, `email: String`, `photoUrl: String`
  - `credits: Long` (Current balance, e.g., 250 initial + daily claims)
  - `isPremium: Boolean`, `subscriptionTier: String` ("Free", "Creator Pro", "Studio Max")
  - `referralCode: String` (Unique shareable code)
  - `referredBy: String?`
  - `lastDailyClaim: Timestamp?`
  - `streakDays: Long`
  - `role: String` ("user" or "admin")
- **`users/{userId}/creations/{creationId}`**:
  - `id: String`, `type: String` ("image", "video", "enhancer", "voice", "short")
  - `prompt: String`, `mediaUrl: String`, `thumbnailUrl: String`
  - `parameters: Map<String, String>` (aspect ratio, style, duration, voice)
  - `createdAt: Timestamp`
- **`prompts/{promptId}`**:
  - Curated community and pro prompt vault items categorized by domain.

---

## 5. Phased Implementation Roadmap

1. **Step 1: Project Metadata & Package Configuration**
   - Update `metadata.json` with app title "CreatorX AI" and description.
   - Sync `strings.xml` with `app_name: "CreatorX AI"`.
2. **Step 2: Firebase Backend Provisioning Handshake**
   - Extract keystore fingerprints (`SHA-1` and `SHA-256`) via `keytool`.
   - Execute Firebase UI Consent & `ProvisionFirebase` RPC for `["firestore", "ai_logic"]`.
   - Configure App Check launcher intent wiring in `MainActivity`.
3. **Step 3: Security Rules & Blueprint Definition**
   - Deploy hardened `firestore.rules` and `firebase-blueprint.json` schema.
4. **Step 4: Design System & Theme Engine**
   - Build Neon Obsidian color scheme, typography tokens, glassmorphic card primitives, and navigation indicators.
5. **Step 5: Core Repositories & Engine Services**
   - Implement `AiStudioRepository` utilizing `Firebase.ai` for prompt crafting, storyboarding, scriptwriting, voice synthesis parameterization, and image generation.
   - Implement `FirestoreUserRepository` for credits balance, streak claiming, referral redemption, and creation history.
6. **Step 6: Studio Screens & Interactive Modules**
   - Implement the 12 creative screens and tools with responsive controls, state flows, and error boundaries.
7. **Step 7: Verification & Build Compilation**
   - Verify zero unauthenticated leaks, run `compile_applet`, and validate end-to-end functionality.
